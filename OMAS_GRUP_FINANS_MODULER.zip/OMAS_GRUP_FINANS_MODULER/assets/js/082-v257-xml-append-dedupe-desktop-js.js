(function(){
  var ROWS_KEY='v233XmlInvoiceLines', ASSIGN_KEY='v233XmlCategoryAssignments', COMPANY_KEY='v244XmlCompanyAssignments';
  function q(s,r){return (r||document).querySelector(s);} function readJson(k,fb){try{var v=JSON.parse(localStorage.getItem(k)||JSON.stringify(fb));return v==null?fb:v;}catch(e){return fb;}}
  function writeJson(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
  function local(n){return String((n&&(n.localName||n.nodeName))||'').split(':').pop();}
  function walk(el,name,one){var out=[],stack=el?[el]:[],target=String(name||'').toLowerCase();while(stack.length){var n=stack.shift();if(n.nodeType===1&&local(n).toLowerCase()===target){if(one)return n;out.push(n);}var kids=n.children||[];for(var i=0;i<kids.length;i++)stack.push(kids[i]);}return one?null:out;}
  function one(el,n){return walk(el,n,true);} function all(el,n){return walk(el,n,false);} function tx(el){return el?(el.textContent||'').trim():'';}
  function num(v){v=String(v==null?'':v).trim();if(v.indexOf(',')>-1)v=v.replace(/\./g,'').replace(',','.');v=v.replace(/[^0-9.\-]/g,'');var n=Number(v);return isFinite(n)?n:0;}
  function norm(v){return String(v||'').toLocaleUpperCase('tr-TR').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^A-Z0-9]+/g,' ').trim();}
  function dedupeKey(r){if(r&&r.xmlDedupeKey)return r.xmlDedupeKey;return [r&&r.uuid||'',r&&r.invoiceNo||'',r&&r.date||'',r&&r.supplier||'',r&&r.lineNo||'',r&&r.name||'',Number(r&&r.matrah||0).toFixed(2),Number(r&&r.kdv||0).toFixed(2),r&&r.currency||'TRY'].map(norm).join('|');}
  function stableKey(r){return [r&&r.file||'',r&&r.invoiceNo||'',r&&r.lineNo||'',r&&r.name||'',r&&r.supplier||''].join('||').toLocaleUpperCase('tr-TR');}
  function parseXml(xml,file){
    var doc=new DOMParser().parseFromString(xml,'text/xml');
    if(doc.getElementsByTagName('parsererror').length)throw new Error(file+': XML okunamadı');
    var root=doc.documentElement,invNo=tx(one(root,'ID'))||file,uuid=tx(one(root,'UUID')),date=tx(one(root,'IssueDate'));
    var rate=one(root,'PricingExchangeRate'),sourceCurrency=(tx(one(rate,'SourceCurrencyCode'))||'').toUpperCase(),currency=(sourceCurrency||tx(one(root,'DocumentCurrencyCode'))||'TRY').toUpperCase();
    var rateNode=one(rate,'CalculationRate')||one(root,'CalculationRate'),exchangeRate=num(tx(rateNode))||1;if(currency==='TL'||currency==='TRL')currency='TRY';
    var fx=(sourceCurrency&&(currency==='EUR'||currency==='USD')&&exchangeRate>0)?exchangeRate:1;
    var sup=one(root,'AccountingSupplierParty')||one(root,'SellerSupplierParty'),party=one(sup,'Party')||sup;
    var contact=one(party,'Contact')||one(sup,'Contact')||one(one(party,'PartyName'),'Contact');
    var person=one(contact,'Person')||one(sup,'Person')||one(party,'Person')||one(one(party,'PartyName'),'Person');
    var supplier=((tx(one(person,'FirstName'))+' '+tx(one(person,'FamilyName'))).trim())||tx(one(one(party,'PartyName'),'Name'))||tx(one(party,'Name'))||'-';
    if(/^t(ü|u)rkiye$/i.test(supplier))supplier='-';
    var out=[],lines=all(root,'InvoiceLine');if(!lines.length)lines=all(root,'CreditNoteLine');
    lines.forEach(function(ln,i){
      var item=one(ln,'Item'),price=one(ln,'Price'),tax=one(ln,'TaxSubtotal')||one(ln,'TaxTotal'),qty=one(ln,'InvoicedQuantity')||one(ln,'CreditedQuantity');
      var name=((tx(one(item,'Name'))+' '+tx(one(item,'Description'))).trim())||tx(one(ln,'Note'))||'Kalem';
      var matrahRaw=num(tx(one(ln,'LineExtensionAmount'))),kdvRaw=num(tx(one(tax,'TaxAmount'))),unitPriceRaw=num(tx(one(price,'PriceAmount')));
      var matrah=matrahRaw*fx,kdv=kdvRaw*fx,unitPrice=unitPriceRaw*fx;
      var key=[uuid||invNo,date,supplier,i+1,name,matrah.toFixed(2),kdv.toFixed(2),currency].map(norm).join('|');
      out.push({id:'xml||'+key,xmlDedupeKey:key,file:file,invoiceNo:invNo,uuid:uuid,date:date,supplier:supplier,lineNo:i+1,name:name,qty:num(tx(qty)),unit:qty?(qty.getAttribute('unitCode')||''):'',unitPrice:unitPrice,matrah:matrah,kdv:kdv,total:matrah+kdv,kdvPct:num(tx(one(tax,'Percent'))),currency:currency,exchangeRate:fx,originalUnitPrice:unitPriceRaw,originalMatrah:matrahRaw,originalKdv:kdvRaw,originalTotal:matrahRaw+kdvRaw});
    });
    return out;
  }
  function mergeRows(oldRows,newRows){var merged=oldRows.slice(),seen={},added=0,skipped=0;oldRows.forEach(function(r){seen[dedupeKey(r)]=1;if(r&&r.id)seen[String(r.id)]=1;});newRows.forEach(function(r){var k=dedupeKey(r);if(seen[k]||seen[String(r.id)]){skipped++;return;}merged.push(r);seen[k]=1;seen[String(r.id)]=1;added++;});return {rows:merged,added:added,skipped:skipped};}
  function carryAssignments(oldRows,mergedRows){var oldAss=readJson(ASSIGN_KEY,{}),oldCo=readJson(COMPANY_KEY,{}),nextAss={},nextCo={},byStableAss={},byStableCo={},byDedupeAss={},byDedupeCo={};oldRows.forEach(function(r){var sk=stableKey(r),dk=dedupeKey(r);if(oldAss[r.id]){byStableAss[sk]=oldAss[r.id];byDedupeAss[dk]=oldAss[r.id];}if(oldCo[r.id]){byStableCo[sk]=oldCo[r.id];byDedupeCo[dk]=oldCo[r.id];}});mergedRows.forEach(function(r){var sk=stableKey(r),dk=dedupeKey(r);if(oldAss[r.id])nextAss[r.id]=oldAss[r.id];else if(byDedupeAss[dk])nextAss[r.id]=byDedupeAss[dk];else if(byStableAss[sk])nextAss[r.id]=byStableAss[sk];if(oldCo[r.id])nextCo[r.id]=oldCo[r.id];else if(byDedupeCo[dk])nextCo[r.id]=byDedupeCo[dk];else if(byStableCo[sk])nextCo[r.id]=byStableCo[sk];});writeJson(ASSIGN_KEY,nextAss);writeJson(COMPANY_KEY,nextCo);}
  function refresh(){try{if(window.v233RenderXml)window.v233RenderXml();}catch(e){}try{if(window.v233RenderCategory)window.v233RenderCategory();}catch(e){}try{if(window.v234RenderXmlMemory)window.v234RenderXmlMemory();}catch(e){}try{if(window.v262RenderCategoryReport)window.v262RenderCategoryReport();}catch(e){}}
  function readFilesAppend(){var input=q('#v233XmlFiles'),files=input&&input.files?Array.prototype.slice.call(input.files):[],host=q('#v231XmlOut');if(!files.length){if(host){host.className='v226-empty';host.textContent='Dosya seçilmedi.';}return;}if(host){host.className='v226-empty';host.textContent=files.length+' XML okunuyor; eski hafıza korunacak, tekrar gelen faturalar atlanacak...';}var oldRows=readJson(ROWS_KEY,[]);Promise.all(files.map(function(f){return f.text().then(function(t){return parseXml(t,f.name);});})).then(function(groups){var incoming=[];groups.forEach(function(g){incoming=incoming.concat(g);});var m=mergeRows(oldRows,incoming);writeJson(ROWS_KEY,m.rows);carryAssignments(oldRows,m.rows);refresh();if(host){host.className='';host.insertAdjacentHTML('afterbegin','<div class="v233-note">XML eklendi. Yeni kalem: <strong>'+m.added+'</strong>. Zaten kayıtlı diye atlanan kalem: <strong>'+m.skipped+'</strong>. Toplam hafıza: <strong>'+m.rows.length+'</strong> kalem.</div>');}if(typeof window.v225InvoiceShow==='function')window.v225InvoiceShow('category');}).catch(function(e){if(host){host.className='v226-empty';host.textContent=e.message||String(e);}});}
  function wire(){var btn=q('#v233XmlRead');if(btn&&!btn.__v257AppendWired){btn.__v257AppendWired=true;btn.onclick=function(e){if(e)e.preventDefault();readFilesAppend();};}}
  document.addEventListener('click',function(e){var btn=e.target&&e.target.closest&&e.target.closest('#v233XmlRead');if(btn){e.preventDefault();e.stopImmediatePropagation();readFilesAppend();return false;}},true);
  document.addEventListener('DOMContentLoaded',function(){setTimeout(wire,500);setTimeout(wire,1500);});setInterval(wire,1000);
  window.v257ReadXmlFilesAppend=readFilesAppend;
})();
